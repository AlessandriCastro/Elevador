public class Main {
    public static void main(String[] args) {
        Simulador simulador = new Simulador(5, 2, 100);
        Predio predio = simulador.getPredio();

        simulador.iniciar();

    }
}

